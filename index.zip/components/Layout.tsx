
import React from 'react';
import { useApp } from '../context/AppContext';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const { user, settings } = useApp();

  if (!user) return <>{children}</>;

  // Updated navigation: Assets and About are now in the Profile section
  const tabs = user.isAdmin 
    ? [
        { id: 'admin', icon: '⚙️', label: 'Admin' },
        { id: 'profile', icon: '👤', label: 'Sign Out' }
      ]
    : [
        { id: 'home', icon: '🏠', label: 'Home' },
        { id: 'invest', icon: '⚡', label: 'Market' },
        { id: 'wallet', icon: '💰', label: 'Wallet' },
        { id: 'team', icon: '👥', label: 'Team' },
        { id: 'profile', icon: '👤', label: 'Profile' }
      ];

  return (
    <div className="min-h-screen pb-24 relative overflow-x-hidden bg-[#0f172a]">
      <header className="p-4 glass sticky top-0 z-50 flex justify-between items-center shadow-md">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-emerald-500 rounded-lg flex items-center justify-center text-lg shadow-lg shadow-emerald-500/20">
            {settings.appLogo}
          </div>
          <h1 className="text-lg font-bold tracking-tight">{settings.appName}</h1>
        </div>
        {!user.isAdmin && (
          <div className="flex items-center gap-2 bg-slate-900/50 px-3 py-1.5 rounded-full border border-white/5">
            <div className="text-right">
              <p className="text-[10px] text-slate-400 uppercase font-black leading-none mb-0.5">Wallet</p>
              <p className="font-bold text-emerald-400 text-sm">₹{user.balance.toFixed(0)}</p>
            </div>
          </div>
        )}
      </header>

      <main className="max-w-md mx-auto p-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
        {children}
      </main>

      <nav className="fixed bottom-0 left-0 right-0 glass border-t border-slate-800 px-1 py-3 z-50">
        <div className="max-w-md mx-auto flex justify-between items-center px-1">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-1 transition-all duration-200 flex-1 min-w-0 ${
                activeTab === tab.id ? 'text-emerald-400 scale-105' : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              <span className="text-lg">{tab.icon}</span>
              <span className="text-[8px] font-bold uppercase tracking-tight truncate w-full text-center">{tab.label}</span>
              {activeTab === tab.id && (
                <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full shadow-[0_0_8px_rgba(52,211,153,0.8)]"></div>
              )}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
};
