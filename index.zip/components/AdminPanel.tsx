
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Product, GiftCode, AppSettings } from '../types';

export const AdminPanel: React.FC = () => {
  const { 
    transactions, 
    allUsersList, 
    products, 
    collectMidnightEarnings, 
    updateUserBalance, 
    deleteUser, 
    approveTransaction, 
    rejectTransaction, 
    addProduct, 
    removeProduct,
    giftCodes,
    createGiftCode,
    settings,
    updateSettings
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'stats' | 'users' | 'recharges' | 'withdrawals' | 'products' | 'gifts' | 'history' | 'settings'>('stats');
  
  // Settings Form State
  const [formSettings, setFormSettings] = useState<AppSettings>(settings);

  // Product Form State
  const [newProd, setNewProd] = useState<Partial<Product>>({
    name: '', price: 0, dailyIncome: 0, validityDays: 30, category: 'Starter'
  });

  // Gift Form State
  const [newGift, setNewGift] = useState<Partial<GiftCode>>({
    code: '', rewardAmount: 0, maxUses: 10
  });

  // Calculate statistics for the dashboard
  const totalDeposits = transactions
    .filter(t => t.type === 'recharge' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalWithdrawals = transactions
    .filter(t => t.type === 'withdraw' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0);

  const activeUsers = allUsersList.filter(u => !u.isAdmin).length;

  const handleSaveSettings = () => {
    updateSettings(formSettings);
    alert("System settings updated successfully!");
  };

  const handleAddProduct = () => {
    if (!newProd.name || !newProd.price) return;
    const p: Product = {
      id: 'p' + Date.now(),
      name: newProd.name!,
      price: newProd.price!,
      dailyIncome: newProd.dailyIncome!,
      validityDays: newProd.validityDays!,
      category: newProd.category as any,
      image: `https://picsum.photos/seed/${newProd.name}/400/400`
    };
    addProduct(p);
    setNewProd({ name: '', price: 0, dailyIncome: 0, validityDays: 30, category: 'Starter' });
    alert("New plan added to marketplace!");
  };

  const handleCreateGift = () => {
    if (!newGift.code || !newGift.rewardAmount) return;
    const g: GiftCode = {
      code: newGift.code.toUpperCase(),
      rewardAmount: newGift.rewardAmount!,
      maxUses: newGift.maxUses || 100,
      currentUses: 0,
      expiryDate: Date.now() + 86400000 * 30
    };
    createGiftCode(g);
    setNewGift({ code: '', rewardAmount: 0, maxUses: 10 });
    alert("New gift voucher generated!");
  };

  const handleReject = (txId: string) => {
    const reason = prompt("Enter reason for rejection:");
    if (reason !== null) rejectTransaction(txId, reason);
  };

  const tabs = ['stats', 'users', 'recharges', 'withdrawals', 'products', 'gifts', 'history', 'settings'];

  return (
    <div className="space-y-5 pb-10">
      <div className="flex gap-1.5 p-1 glass rounded-2xl overflow-x-auto no-scrollbar scroll-smooth border-white/5">
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveSubTab(tab as any)}
            className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase transition-all whitespace-nowrap ${activeSubTab === tab ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/20' : 'text-slate-500'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      {activeSubTab === 'settings' && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
          <div className="glass p-6 rounded-[2rem] space-y-4 border-l-4 border-rose-500">
            <h3 className="text-sm font-black uppercase tracking-widest text-rose-400">Platform Identity</h3>
            <div className="space-y-4">
              <div>
                <label className="text-[9px] font-black text-slate-500 ml-1">PLATFORM NAME</label>
                <input 
                  type="text" 
                  value={formSettings.appName} 
                  onChange={e => setFormSettings({...formSettings, appName: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 px-4 text-sm font-bold focus:border-rose-500 outline-none" 
                />
              </div>
              <div>
                <label className="text-[9px] font-black text-slate-500 ml-1">PLATFORM LOGO (EMOJI)</label>
                <input 
                  type="text" 
                  value={formSettings.appLogo} 
                  onChange={e => setFormSettings({...formSettings, appLogo: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 px-4 text-sm font-bold focus:border-rose-500 outline-none text-center text-xl" 
                />
              </div>
            </div>
          </div>

          <div className="glass p-6 rounded-[2rem] space-y-4 border-l-4 border-emerald-500">
            <h3 className="text-sm font-black uppercase tracking-widest text-emerald-400">Financial Rules</h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[9px] font-black text-slate-500 ml-1">MIN RECHARGE (₹)</label>
                <input 
                  type="number" 
                  value={formSettings.minRecharge} 
                  onChange={e => setFormSettings({...formSettings, minRecharge: Number(e.target.value)})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 px-4 text-sm font-bold outline-none" 
                />
              </div>
              <div>
                <label className="text-[9px] font-black text-slate-500 ml-1">MIN PAYOUT (₹)</label>
                <input 
                  type="number" 
                  value={formSettings.minWithdrawal} 
                  onChange={e => setFormSettings({...formSettings, minWithdrawal: Number(e.target.value)})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 px-4 text-sm font-bold outline-none" 
                />
              </div>
            </div>
            <div>
              <label className="text-[9px] font-black text-slate-500 ml-1">ADMIN RECEIVING UPI ID</label>
              <input 
                type="text" 
                value={formSettings.platformUpi} 
                onChange={e => setFormSettings({...formSettings, platformUpi: e.target.value})}
                className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 px-4 text-sm font-bold outline-none" 
              />
            </div>
          </div>

          <div className="glass p-6 rounded-[2rem] space-y-4 border-l-4 border-blue-500">
            <h3 className="text-sm font-black uppercase tracking-widest text-blue-400">Public About Details</h3>
            <textarea 
              value={formSettings.aboutContent} 
              onChange={e => setFormSettings({...formSettings, aboutContent: e.target.value})}
              rows={4}
              className="w-full bg-slate-900 border border-slate-800 rounded-2xl py-3 px-4 text-[11px] font-medium outline-none resize-none" 
              placeholder="About our platform..."
            />
          </div>

          <button 
            onClick={handleSaveSettings}
            className="w-full bg-emerald-500 py-4 rounded-3xl text-black font-black text-sm shadow-2xl shadow-emerald-500/20 active:scale-95 transition-all"
          >
            Commit System Settings 💾
          </button>
        </div>
      )}

      {activeSubTab === 'stats' && (
        <div className="space-y-4 animate-in fade-in">
          <div className="grid grid-cols-2 gap-3">
            <div className="glass p-5 rounded-3xl border-l-4 border-emerald-500 bg-emerald-500/5">
              <p className="text-[8px] text-slate-500 uppercase font-black mb-1">Total Deposits</p>
              <p className="text-2xl font-black text-emerald-400">₹{totalDeposits}</p>
            </div>
            <div className="glass p-5 rounded-3xl border-l-4 border-rose-500 bg-rose-500/5">
              <p className="text-[8px] text-slate-500 uppercase font-black mb-1">Total Payouts</p>
              <p className="text-2xl font-black text-rose-400">₹{totalWithdrawals}</p>
            </div>
            <div className="glass p-5 rounded-3xl border-white/5">
              <p className="text-[8px] text-slate-500 uppercase font-black mb-1">Verified Users</p>
              <p className="text-2xl font-black">{activeUsers}</p>
            </div>
            <div className="glass p-5 rounded-3xl border-white/5">
              <p className="text-[8px] text-slate-500 uppercase font-black mb-1">Pending Requests</p>
              <p className="text-2xl font-black text-yellow-500">{transactions.filter(t => t.status === 'pending').length}</p>
            </div>
          </div>

          <div className="glass p-8 rounded-[2.5rem] border-l-4 border-yellow-500 bg-yellow-500/5 text-center">
            <h3 className="text-sm font-black mb-1 uppercase tracking-wider text-yellow-500">Yield Distribution</h3>
            <p className="text-slate-400 text-[10px] mb-6 font-medium leading-relaxed">Trigger this to manually push daily returns to all active grid modules globally.</p>
            <button
              onClick={() => collectMidnightEarnings()}
              className="w-full bg-yellow-500 py-4 rounded-3xl text-black font-black text-xs shadow-xl active:scale-95 transition-all"
            >
              Start Global Profit Harvest ⚙️
            </button>
          </div>
        </div>
      )}

      {activeSubTab === 'users' && (
        <div className="space-y-3">
          <h3 className="text-lg font-black px-1">User Management</h3>
          <div className="space-y-2">
            {allUsersList.filter(u => !u.isAdmin).map(u => (
              <div key={u.id} className="glass p-4 rounded-3xl space-y-3 border-white/5">
                <div className="flex justify-between items-start">
                  <div className="min-w-0">
                    <p className="font-black text-sm truncate">{u.name}</p>
                    <p className="text-[9px] text-slate-500 font-mono">{u.phone}</p>
                  </div>
                  <button onClick={() => deleteUser(u.id)} className="text-[8px] font-black text-rose-500 bg-rose-500/10 px-2 py-1 rounded-lg uppercase">Ban</button>
                </div>
                <div className="flex gap-3 items-center pt-2 border-t border-white/5">
                  <div className="flex-1">
                    <p className="text-[8px] text-slate-500 uppercase font-black">Account Bal</p>
                    <p className="font-black text-emerald-400 text-sm">₹{u.balance.toFixed(0)}</p>
                  </div>
                  <button onClick={() => {
                      const amt = prompt("New wallet balance for " + u.name + ":");
                      if (amt) updateUserBalance(u.id, Number(amt));
                    }} className="bg-white/5 px-4 py-2 rounded-xl text-[9px] font-black transition-all hover:bg-white/10">Set Bal</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'recharges' && (
        <div className="space-y-3">
          <h3 className="text-lg font-black px-1">Verify Deposits</h3>
          <div className="space-y-2">
            {transactions.filter(t => t.type === 'recharge' && t.status === 'pending').map(t => (
              <div key={t.id} className="glass p-5 rounded-3xl border-l-4 border-emerald-500">
                <div className="flex justify-between mb-4">
                  <div className="min-w-0">
                    <p className="text-[12px] font-black truncate text-emerald-400">UTR: {t.utr}</p>
                    <p className="text-[8px] text-slate-500 font-black uppercase mt-1">SENDER: {allUsersList.find(u => u.id === t.userId)?.name}</p>
                  </div>
                  <p className="text-2xl font-black text-emerald-400 ml-2">₹{t.amount}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => approveTransaction(t.id)} className="flex-1 bg-emerald-500 text-black py-3 rounded-2xl font-black text-[10px] active:scale-95 transition-all">APPROVE ✅</button>
                  <button onClick={() => handleReject(t.id)} className="flex-1 bg-rose-500 text-white py-3 rounded-2xl font-black text-[10px] active:scale-95 transition-all">REJECT ❌</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'withdrawals' && (
        <div className="space-y-3">
          <h3 className="text-lg font-black px-1">Verify Payouts</h3>
          <div className="space-y-2">
            {transactions.filter(t => t.type === 'withdraw' && t.status === 'pending').map(t => (
              <div key={t.id} className="glass p-5 rounded-3xl border-l-4 border-rose-500">
                <div className="flex justify-between mb-4">
                  <div className="min-w-0">
                    <p className="text-[12px] font-black truncate text-rose-400">UPI: {t.upiId}</p>
                    <p className="text-[8px] text-slate-500 font-black uppercase mt-1">USER: {allUsersList.find(u => u.id === t.userId)?.name}</p>
                  </div>
                  <p className="text-2xl font-black text-rose-400 ml-2">₹{t.amount}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => approveTransaction(t.id)} className="flex-1 bg-emerald-500 text-black py-3 rounded-2xl font-black text-[10px] active:scale-95 transition-all">CONFIRM PAID ✅</button>
                  <button onClick={() => handleReject(t.id)} className="flex-1 bg-rose-500 text-white py-3 rounded-2xl font-black text-[10px] active:scale-95 transition-all">DECLINE ❌</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'gifts' && (
        <div className="space-y-5 animate-in fade-in">
          <div className="glass p-6 rounded-[2rem] space-y-4 border-l-4 border-emerald-500">
            <h3 className="font-black text-sm uppercase text-slate-400">Generate Bonus Code</h3>
            <div className="space-y-3">
              <input type="text" placeholder="CODE (e.g. MEGA500)" className="w-full bg-slate-900 border border-slate-700 p-4 rounded-2xl text-sm font-black uppercase" value={newGift.code} onChange={e => setNewGift({...newGift, code: e.target.value})} />
              <div className="grid grid-cols-2 gap-2">
                <input type="number" placeholder="Reward ₹" className="w-full bg-slate-900 border border-slate-700 p-4 rounded-2xl text-sm font-black" value={newGift.rewardAmount || ''} onChange={e => setNewGift({...newGift, rewardAmount: Number(e.target.value)})} />
                <input type="number" placeholder="Max Uses" className="w-full bg-slate-900 border border-slate-700 p-4 rounded-2xl text-sm font-black" value={newGift.maxUses || ''} onChange={e => setNewGift({...newGift, maxUses: Number(e.target.value)})} />
              </div>
              <button onClick={handleCreateGift} className="w-full bg-emerald-500 text-black font-black py-4 rounded-3xl shadow-xl active:scale-95 transition-all">Create Voucher Protocol 🎁</button>
            </div>
          </div>
          <div className="space-y-2">
            <h4 className="px-2 text-[10px] font-black uppercase text-slate-500 tracking-widest">Live Vouchers</h4>
            {giftCodes.map(g => (
              <div key={g.code} className="glass p-4 rounded-3xl flex justify-between items-center border-white/5">
                <div>
                  <p className="font-black text-emerald-400 tracking-wider text-sm">{g.code}</p>
                  <p className="text-[9px] text-slate-500 font-bold uppercase">₹{g.rewardAmount} Reward</p>
                </div>
                <div className="text-right">
                  <p className="text-[9px] font-black text-slate-400">{g.currentUses} / {g.maxUses} Used</p>
                  <div className="w-20 h-1 bg-slate-800 rounded-full mt-1 overflow-hidden">
                    <div className="bg-emerald-500 h-full" style={{ width: `${(g.currentUses/g.maxUses)*100}%` }}></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'history' && (
        <div className="space-y-3 animate-in fade-in">
          <h3 className="text-lg font-black px-1">Global Audit Log</h3>
          <div className="space-y-2 max-h-[500px] overflow-y-auto no-scrollbar">
            {transactions.map(tx => {
              const u = allUsersList.find(u => u.id === tx.userId);
              return (
                <div key={tx.id} className="glass p-4 rounded-2xl flex justify-between items-center border-white/5">
                  <div className="min-w-0">
                    <p className="text-[10px] font-black uppercase text-slate-400 mb-1">{tx.type} | {u?.name || 'Unknown'}</p>
                    <p className="text-[8px] text-slate-500 font-mono truncate w-40">{tx.details}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`font-black text-sm ${tx.type === 'recharge' ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {tx.type === 'recharge' ? '+' : '-'}₹{tx.amount}
                    </p>
                    <p className="text-[7px] font-black text-slate-600 uppercase mt-1">{tx.status}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeSubTab === 'products' && (
        <div className="space-y-5 animate-in fade-in">
          <div className="glass p-6 rounded-[2rem] space-y-4 border-l-4 border-blue-500">
            <h3 className="font-black text-sm uppercase text-slate-400">Inject New Power Plan</h3>
            <div className="space-y-3">
              <input type="text" placeholder="Plan Name" className="w-full bg-slate-900 border border-slate-700 p-4 rounded-2xl text-sm font-black" value={newProd.name} onChange={e => setNewProd({...newProd, name: e.target.value})} />
              <div className="grid grid-cols-2 gap-2">
                <input type="number" placeholder="Price ₹" className="w-full bg-slate-900 border border-slate-700 p-4 rounded-2xl text-sm font-black" value={newProd.price || ''} onChange={e => setNewProd({...newProd, price: Number(e.target.value)})} />
                <input type="number" placeholder="Daily Profit ₹" className="w-full bg-slate-900 border border-slate-700 p-4 rounded-2xl text-sm font-black" value={newProd.dailyIncome || ''} onChange={e => setNewProd({...newProd, dailyIncome: Number(e.target.value)})} />
              </div>
              <input type="number" placeholder="Validity Days" className="w-full bg-slate-900 border border-slate-700 p-4 rounded-2xl text-sm font-black" value={newProd.validityDays || ''} onChange={e => setNewProd({...newProd, validityDays: Number(e.target.value)})} />
              <button onClick={handleAddProduct} className="w-full bg-blue-500 text-white font-black py-4 rounded-3xl shadow-xl active:scale-95 transition-all">Inject to Marketplace ⚡</button>
            </div>
          </div>
          <div className="space-y-2">
            <h4 className="px-2 text-[10px] font-black uppercase text-slate-500 tracking-widest">Inventory Log</h4>
            {products.map(p => (
              <div key={p.id} className="glass p-4 rounded-3xl flex justify-between items-center border-white/5">
                <div className="flex gap-4 items-center min-w-0">
                  <img src={p.image} className="w-10 h-10 rounded-xl object-cover" />
                  <div className="min-w-0">
                    <p className="font-bold text-xs truncate">{p.name}</p>
                    <p className="text-[8px] text-slate-500">Cost: ₹{p.price} | Yield: ₹{p.dailyIncome}</p>
                  </div>
                </div>
                <button onClick={() => removeProduct(p.id)} className="text-rose-500 text-xs font-black uppercase px-2">Delete</button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
