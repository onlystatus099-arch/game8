
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getInvestmentAdvice = async (amount: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a short, professional, and encouraging investment advice for a user looking to invest ${amount} currency units in a green energy powerbank project. Keep it under 50 words.`,
    });
    return response.text || "Invest wisely for a greener future.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Start your green energy journey today!";
  }
};

export const generateProductDescription = async (productName: string, dailyIncome: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a catchy 1-sentence sales pitch for a high-yield powerbank product named "${productName}" that generates ${dailyIncome} income daily.`,
    });
    return response.text || "Empower your portfolio with sustainable energy returns.";
  } catch (error) {
    return "High efficiency energy harvesting module.";
  }
};
