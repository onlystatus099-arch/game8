
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, Product, Transaction, GiftCode, Investment, AppSettings } from '../types';
import { INITIAL_PRODUCTS } from '../constants';

interface AppContextType {
  user: User | null;
  allUsersList: User[];
  products: Product[];
  transactions: Transaction[];
  giftCodes: GiftCode[];
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  login: (phone: string, password: string) => Promise<boolean>;
  register: (name: string, phone: string, password: string, referralCode?: string) => Promise<boolean>;
  logout: () => void;
  recharge: (amount: number, utr: string) => void;
  withdraw: (amount: number, upiId: string) => Promise<boolean>;
  buyProduct: (productId: string) => Promise<boolean>;
  redeemGift: (code: string) => Promise<string>;
  collectMidnightEarnings: () => void;
  updateUserBalance: (userId: string, newBalance: number) => void;
  deleteUser: (userId: string) => void;
  approveTransaction: (txId: string) => void;
  rejectTransaction: (txId: string, reason?: string) => void;
  addProduct: (product: Product) => void;
  removeProduct: (productId: string) => void;
  createGiftCode: (gift: GiftCode) => void;
}

const DEFAULT_SETTINGS: AppSettings = {
  appName: 'VoltGain Pro',
  appLogo: '⚡',
  aboutContent: 'Welcome to VoltGain, the world\'s leading green energy investment platform. Our mission is to democratize energy infrastructure investment through smart technology.',
  platformUpi: 'payment@upi',
  minRecharge: 500,
  minWithdrawal: 150,
  allowWithdrawals: true
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [allUsers, setAllUsers] = useState<Record<string, any>>({});
  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [giftCodes, setGiftCodes] = useState<GiftCode[]>([]);

  useEffect(() => {
    // Load Core Data
    const savedUsers = localStorage.getItem('volt_all_users');
    let db = savedUsers ? JSON.parse(savedUsers) : {};
    
    // Updated admin credentials as per request: admin / admin786
    if (!db['admin']) {
      db['admin'] = {
        id: 'admin-root',
        name: 'System Admin',
        phone: 'admin',
        password: 'admin786',
        balance: 999999,
        totalInvestment: 0,
        totalEarnings: 0,
        referralCode: 'ADMIN_ROOT',
        referrals: 0,
        isAdmin: true,
        activeInvestments: []
      };
      localStorage.setItem('volt_all_users', JSON.stringify(db));
    } else if (db['admin'].password !== 'admin786') {
      // Ensure existing admin also gets the new password
      db['admin'].password = 'admin786';
      localStorage.setItem('volt_all_users', JSON.stringify(db));
    }
    setAllUsers(db);

    const loggedInId = localStorage.getItem('volt_logged_in_id');
    if (loggedInId && db[loggedInId]) {
      setUser(db[loggedInId]);
    }

    const savedTxs = localStorage.getItem('volt_transactions');
    if (savedTxs) setTransactions(JSON.parse(savedTxs));

    const savedProducts = localStorage.getItem('volt_products');
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    } else {
      setProducts(INITIAL_PRODUCTS);
    }

    const savedSettings = localStorage.getItem('volt_settings');
    if (savedSettings) setSettings(JSON.parse(savedSettings));

    const savedGifts = localStorage.getItem('volt_gifts');
    if (savedGifts) setGiftCodes(JSON.parse(savedGifts));
  }, []);

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    localStorage.setItem('volt_settings', JSON.stringify(updated));
  };

  const syncStorage = (updatedUser: User | null, updatedAllUsers: Record<string, any>, updatedTxs?: Transaction[], updatedProducts?: Product[]) => {
    if (updatedUser) {
      updatedAllUsers[updatedUser.phone] = updatedUser;
      localStorage.setItem('volt_logged_in_id', updatedUser.phone);
    } else {
      localStorage.removeItem('volt_logged_in_id');
    }
    
    setUser(updatedUser);
    setAllUsers(updatedAllUsers);
    localStorage.setItem('volt_all_users', JSON.stringify(updatedAllUsers));
    
    if (updatedTxs) {
      setTransactions(updatedTxs);
      localStorage.setItem('volt_transactions', JSON.stringify(updatedTxs));
    }

    if (updatedProducts) {
      setProducts(updatedProducts);
      localStorage.setItem('volt_products', JSON.stringify(updatedProducts));
    }
  };

  const register = async (name: string, phone: string, password: string, referralCode?: string): Promise<boolean> => {
    if (allUsers[phone]) return false;
    const newUser: User & { password?: string } = {
      id: 'u' + Math.random().toString(36).substr(2, 9),
      name,
      phone,
      password,
      balance: 50,
      totalInvestment: 0,
      totalEarnings: 0,
      referralCode: 'VOLT' + phone.substr(-4).toUpperCase(),
      referrals: 0,
      isAdmin: false,
      activeInvestments: []
    };
    const newDb = { ...allUsers, [phone]: newUser };
    syncStorage(newUser, newDb);
    return true;
  };

  const login = async (phone: string, password: string): Promise<boolean> => {
    const foundUser = allUsers[phone];
    if (foundUser && foundUser.password === password) {
      syncStorage(foundUser, allUsers);
      return true;
    }
    return false;
  };

  const logout = () => syncStorage(null, allUsers);

  const recharge = (amount: number, utr: string) => {
    if (!user) return;
    const newTx: Transaction = {
      id: 'tx' + Math.random().toString(36).substr(2, 9),
      userId: user.id,
      type: 'recharge',
      amount,
      status: 'pending',
      timestamp: Date.now(),
      utr,
      details: `UTR Verification Pending`
    };
    const newTxs = [newTx, ...transactions];
    syncStorage(user, allUsers, newTxs);
  };

  const withdraw = async (amount: number, upiId: string): Promise<boolean> => {
    if (!user || user.balance < amount) return false;
    const newTx: Transaction = {
      id: 'tx' + Math.random().toString(36).substr(2, 9),
      userId: user.id,
      type: 'withdraw',
      amount,
      status: 'pending',
      timestamp: Date.now(),
      upiId,
      details: `Payout to ${upiId}`
    };
    const updatedUser = { ...user, balance: user.balance - amount };
    const newTxs = [newTx, ...transactions];
    syncStorage(updatedUser, allUsers, newTxs);
    return true;
  };

  const buyProduct = async (productId: string): Promise<boolean> => {
    if (!user) return false;
    const product = products.find(p => p.id === productId);
    if (!product || user.balance < product.price) return false;

    const newInvestment: Investment = {
      id: 'inv' + Math.random().toString(36).substr(2, 9),
      productId: product.id,
      productName: product.name,
      amount: product.price,
      dailyReturn: product.dailyIncome,
      purchaseDate: Date.now(),
      expiryDate: Date.now() + (product.validityDays * 86400000),
      lastCollectionDate: Date.now()
    };

    const updatedUser: User = {
      ...user,
      balance: user.balance - product.price,
      totalInvestment: user.totalInvestment + product.price,
      activeInvestments: [...user.activeInvestments, newInvestment]
    };
    const newTxs: Transaction[] = [{
      id: 'tx' + Math.random().toString(36).substr(2, 9),
      userId: user.id,
      type: 'investment',
      amount: product.price,
      status: 'completed',
      timestamp: Date.now(),
      details: `Plan Activated: ${product.name}`
    }, ...transactions];
    syncStorage(updatedUser, allUsers, newTxs);
    return true;
  };

  const redeemGift = async (code: string): Promise<string> => {
    if (!user) return "Session error";
    const gift = giftCodes.find(g => g.code === code);
    if (!gift) return "Invalid code";
    if (gift.currentUses >= gift.maxUses) return "Code limit reached";
    const updatedGifts = giftCodes.map(g => g.code === code ? { ...g, currentUses: g.currentUses + 1 } : g);
    setGiftCodes(updatedGifts);
    localStorage.setItem('volt_gifts', JSON.stringify(updatedGifts));
    
    const updatedUser = { ...user, balance: user.balance + gift.rewardAmount };
    const newTxs: Transaction[] = [{
      id: 'tx' + Math.random().toString(36).substr(2, 9),
      userId: user.id,
      type: 'bonus',
      amount: gift.rewardAmount,
      status: 'completed',
      timestamp: Date.now(),
      details: `Gift Redeemed: ${code}`
    }, ...transactions];
    syncStorage(updatedUser, allUsers, newTxs);
    return `Success! ₹${gift.rewardAmount} added.`;
  };

  const collectMidnightEarnings = useCallback(() => {
    const now = Date.now();
    const newDb = { ...allUsers };
    let txLog: Transaction[] = [...transactions];

    Object.keys(newDb).forEach(phone => {
      const u = newDb[phone];
      let earned = 0;
      const updatedInvestments = u.activeInvestments.map((inv: Investment) => {
        if (inv.expiryDate > now) {
          earned += inv.dailyReturn;
          return { ...inv, lastCollectionDate: now };
        }
        return inv;
      });

      if (earned > 0) {
        u.balance += earned;
        u.totalEarnings += earned;
        u.activeInvestments = updatedInvestments;
        txLog.unshift({
          id: 'coll' + Math.random().toString(36).substr(2, 9),
          userId: u.id,
          type: 'bonus',
          amount: earned,
          status: 'completed',
          timestamp: now,
          details: 'Daily Profit Credited'
        });
      }
    });

    setAllUsers(newDb);
    setTransactions(txLog);
    localStorage.setItem('volt_all_users', JSON.stringify(newDb));
    localStorage.setItem('volt_transactions', JSON.stringify(txLog));
    if (user) setUser(newDb[user.phone]);
    alert("Profits distributed to all active accounts!");
  }, [user, allUsers, transactions]);

  const updateUserBalance = (userId: string, newBalance: number) => {
    const phone = Object.keys(allUsers).find(p => allUsers[p].id === userId);
    if (!phone) return;
    const updatedDb = { ...allUsers, [phone]: { ...allUsers[phone], balance: newBalance } };
    syncStorage(user && user.id === userId ? updatedDb[phone] : user, updatedDb);
  };

  const deleteUser = (userId: string) => {
    const phone = Object.keys(allUsers).find(p => allUsers[p].id === userId);
    if (!phone || phone === 'admin') return; 
    const { [phone]: _, ...updatedDb } = allUsers;
    syncStorage(user?.id === userId ? null : user, updatedDb);
  };

  const approveTransaction = (txId: string) => {
    const txIndex = transactions.findIndex(t => t.id === txId);
    if (txIndex === -1) return;
    const tx = transactions[txIndex];
    if (tx.status !== 'pending') return;

    const newTxs = [...transactions];
    newTxs[txIndex] = { ...tx, status: 'completed' };

    const targetUserPhone = Object.keys(allUsers).find(p => allUsers[p].id === tx.userId);
    if (!targetUserPhone) return;

    const updatedDb = { ...allUsers };
    if (tx.type === 'recharge') {
      updatedDb[targetUserPhone].balance += tx.amount;
    }
    syncStorage(user?.phone === targetUserPhone ? updatedDb[targetUserPhone] : user, updatedDb, newTxs);
  };

  const rejectTransaction = (txId: string, reason: string = "Declined") => {
    const txIndex = transactions.findIndex(t => t.id === txId);
    if (txIndex === -1) return;
    const tx = transactions[txIndex];
    if (tx.status !== 'pending') return;
    
    const newTxs = [...transactions];
    newTxs[txIndex] = { ...tx, status: 'failed', details: `${tx.details} | Reason: ${reason}` };

    const targetUserPhone = Object.keys(allUsers).find(p => allUsers[p].id === tx.userId);
    if (!targetUserPhone) return;

    const updatedDb = { ...allUsers };
    if (tx.type === 'withdraw') {
      updatedDb[targetUserPhone].balance += tx.amount;
    }

    syncStorage(user?.phone === targetUserPhone ? updatedDb[targetUserPhone] : user, updatedDb, newTxs);
  };

  const addProduct = (product: Product) => {
    const newProducts = [...products, product];
    syncStorage(user, allUsers, transactions, newProducts);
  };

  const removeProduct = (productId: string) => {
    const newProducts = products.filter(p => p.id !== productId);
    syncStorage(user, allUsers, transactions, newProducts);
  };

  const createGiftCode = (gift: GiftCode) => {
    const updated = [...giftCodes, gift];
    setGiftCodes(updated);
    localStorage.setItem('volt_gifts', JSON.stringify(updated));
  };

  return (
    <AppContext.Provider value={{
      user, allUsersList: Object.values(allUsers), products, transactions, giftCodes, settings, updateSettings,
      login, register, logout, recharge, withdraw, buyProduct, redeemGift, collectMidnightEarnings,
      updateUserBalance, deleteUser, approveTransaction, rejectTransaction, addProduct, removeProduct, createGiftCode
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
